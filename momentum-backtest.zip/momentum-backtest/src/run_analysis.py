"""
run_analysis.py
----------------
Main entry point. Loads price data, runs the momentum backtest, compares it
against a buy-and-hold SPY benchmark, prints a metrics summary, saves charts,
and writes a markdown results report.

Usage:
    python src/run_analysis.py
"""

import os

import matplotlib.pyplot as plt
import pandas as pd

from backtest import run_backtest
from metrics import summary_table, max_drawdown

DATA_PATH = "data/prices.csv"
OUTPUT_DIR = "output"
BENCHMARK_TICKER = "SPY"

LOOKBACK_MONTHS = 6
TOP_K = 3
TRANSACTION_COST_BPS = 10.0


def load_data():
    df = pd.read_csv(DATA_PATH, index_col="Date", parse_dates=True)
    df = df.sort_index()
    return df


def format_pct(x):
    return f"{x * 100:.2f}%" if pd.notna(x) else "N/A"


def format_ratio(x):
    return f"{x:.2f}" if pd.notna(x) else "N/A"


def plot_equity_curve(strategy_returns, benchmark_returns, path):
    strat_equity = (1 + strategy_returns).cumprod()
    bench_equity = (1 + benchmark_returns.loc[strategy_returns.index]).cumprod()

    plt.figure(figsize=(11, 6))
    plt.plot(strat_equity.index, strat_equity.values, label="Momentum Strategy", linewidth=2)
    plt.plot(bench_equity.index, bench_equity.values, label="SPY Buy & Hold", linewidth=2, linestyle="--")
    plt.title(f"Growth of $1: Momentum (Top {TOP_K}, {LOOKBACK_MONTHS}mo lookback) vs SPY")
    plt.xlabel("Date")
    plt.ylabel("Growth of $1 (log scale)")
    plt.yscale("log")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def plot_drawdown(strategy_returns, benchmark_returns, path):
    def dd_series(returns):
        cum = (1 + returns).cumprod()
        running_max = cum.cummax()
        return (cum - running_max) / running_max

    strat_dd = dd_series(strategy_returns)
    bench_dd = dd_series(benchmark_returns.loc[strategy_returns.index])

    plt.figure(figsize=(11, 5))
    plt.fill_between(strat_dd.index, strat_dd.values * 100, 0, alpha=0.4, label="Momentum Strategy")
    plt.fill_between(bench_dd.index, bench_dd.values * 100, 0, alpha=0.4, label="SPY Buy & Hold")
    plt.title("Drawdown Over Time (%)")
    plt.xlabel("Date")
    plt.ylabel("Drawdown (%)")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def plot_rolling_sharpe(strategy_returns, benchmark_returns, path, window=126):
    rf_daily = (1.04) ** (1 / 252) - 1

    def rolling_sharpe(returns):
        excess = returns - rf_daily
        return (excess.rolling(window).mean() / excess.rolling(window).std()) * (252 ** 0.5)

    strat_rs = rolling_sharpe(strategy_returns)
    bench_rs = rolling_sharpe(benchmark_returns.loc[strategy_returns.index])

    plt.figure(figsize=(11, 5))
    plt.plot(strat_rs.index, strat_rs.values, label="Momentum Strategy")
    plt.plot(bench_rs.index, bench_rs.values, label="SPY Buy & Hold", linestyle="--")
    plt.axhline(0, color="gray", linewidth=0.8)
    plt.title(f"Rolling {window}-Day Sharpe Ratio")
    plt.xlabel("Date")
    plt.ylabel("Sharpe Ratio (annualized)")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def write_report(strategy_metrics, benchmark_metrics, holdings_log, path):
    lines = []
    lines.append("# Momentum Strategy Backtest — Results Report\n")
    lines.append(f"**Strategy:** Top {TOP_K} stocks by {LOOKBACK_MONTHS}-month momentum, monthly rebalance, "
                 f"{TRANSACTION_COST_BPS:.0f} bps transaction cost per rebalance.\n")
    lines.append(f"**Benchmark:** Buy-and-hold {BENCHMARK_TICKER}\n")
    lines.append("\n## Performance Summary\n")
    lines.append("| Metric | Momentum Strategy | SPY Benchmark |")
    lines.append("|---|---|---|")

    pct_fields = ["Cumulative Return", "CAGR", "Annualized Volatility", "Max Drawdown", "Win Rate"]
    for key in strategy_metrics:
        fmt = format_pct if key in pct_fields else format_ratio
        lines.append(f"| {key} | {fmt(strategy_metrics[key])} | {fmt(benchmark_metrics[key])} |")

    lines.append("\n## Rebalance Log (most recent 10)\n")
    lines.append("| Date | Holdings | Momentum Scores | Turnover | Cost |")
    lines.append("|---|---|---|---|---|")
    for entry in holdings_log[-10:]:
        scores_str = ", ".join(f"{k}: {v*100:.1f}%" for k, v in entry["momentum_scores"].items())
        lines.append(
            f"| {entry['rebalance_date'].date()} | {', '.join(entry['holdings'])} | "
            f"{scores_str} | {entry['turnover']:.2f} | {entry['transaction_cost_pct']:.3f}% |"
        )

    lines.append("\n## Interpretation Notes\n")
    sharpe_diff = strategy_metrics["Sharpe Ratio"] - benchmark_metrics["Sharpe Ratio"]
    outperformed = strategy_metrics["CAGR"] > benchmark_metrics["CAGR"]
    lines.append(
        f"- The strategy {'outperformed' if outperformed else 'underperformed'} SPY on a raw CAGR basis "
        f"({format_pct(strategy_metrics['CAGR'])} vs {format_pct(benchmark_metrics['CAGR'])})."
    )
    lines.append(
        f"- Risk-adjusted (Sharpe), the strategy's ratio was "
        f"{'higher' if sharpe_diff > 0 else 'lower'} than the benchmark's by {abs(sharpe_diff):.2f}."
    )
    lines.append(
        f"- Max drawdown was {format_pct(strategy_metrics['Max Drawdown'])} for the strategy vs "
        f"{format_pct(benchmark_metrics['Max Drawdown'])} for SPY — "
        f"{'a worse' if strategy_metrics['Max Drawdown'] < benchmark_metrics['Max Drawdown'] else 'a milder'} "
        f"worst-case decline."
    )
    lines.append(
        "- This backtest uses a small, fixed universe of 8 large-cap stocks and synthetic/placeholder "
        "price data (see README) — results should be read as a demonstration of methodology, not as "
        "evidence the strategy works in live markets."
    )

    with open(path, "w") as f:
        f.write("\n".join(lines))


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    prices = load_data()

    benchmark_prices = prices[BENCHMARK_TICKER]
    stock_prices = prices.drop(columns=[BENCHMARK_TICKER])

    print(f"Loaded {len(prices)} days of data for {len(stock_prices.columns)} stocks + benchmark.")
    print(f"Date range: {prices.index[0].date()} to {prices.index[-1].date()}\n")

    print("Running momentum backtest...")
    result = run_backtest(
        stock_prices,
        lookback_months=LOOKBACK_MONTHS,
        top_k=TOP_K,
        transaction_cost_bps=TRANSACTION_COST_BPS,
    )
    strategy_returns = result["daily_returns"]
    benchmark_returns = benchmark_prices.pct_change().fillna(0)

    strategy_metrics = summary_table(strategy_returns)
    benchmark_metrics = summary_table(benchmark_returns.loc[strategy_returns.index])

    print("\n=== PERFORMANCE SUMMARY ===")
    for key in strategy_metrics:
        pct_fields = ["Cumulative Return", "CAGR", "Annualized Volatility", "Max Drawdown", "Win Rate"]
        fmt = format_pct if key in pct_fields else format_ratio
        print(f"{key:24s} | Strategy: {fmt(strategy_metrics[key]):>10s} | SPY: {fmt(benchmark_metrics[key]):>10s}")

    print("\nGenerating charts...")
    plot_equity_curve(strategy_returns, benchmark_returns, f"{OUTPUT_DIR}/equity_curve.png")
    plot_drawdown(strategy_returns, benchmark_returns, f"{OUTPUT_DIR}/drawdown.png")
    plot_rolling_sharpe(strategy_returns, benchmark_returns, f"{OUTPUT_DIR}/rolling_sharpe.png")

    print("Writing report...")
    write_report(strategy_metrics, benchmark_metrics, result["holdings_log"], f"{OUTPUT_DIR}/REPORT.md")

    result["weights_history"].to_csv(f"{OUTPUT_DIR}/rebalance_weights.csv")

    print(f"\nDone. See the '{OUTPUT_DIR}/' folder for charts and REPORT.md")


if __name__ == "__main__":
    main()
