"""
fetch_data.py
-------------
Pulls real historical daily price data from Yahoo Finance via yfinance.

Run this on your own machine (not required in restricted sandboxes) to
replace the placeholder data/prices.csv with real market data:

    python src/fetch_data.py

Requires internet access. If you hit rate limits, wait a few minutes and
retry, or reduce TICKERS / date range.
"""

import pandas as pd
import yfinance as yf

TICKERS = ["AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "JNJ", "KO", "XOM"]
BENCHMARK = "SPY"
START_DATE = "2020-01-01"
END_DATE = "2024-12-31"
OUT_PATH = "data/prices.csv"


def main():
    all_tickers = TICKERS + [BENCHMARK]
    print(f"Downloading {len(all_tickers)} tickers from {START_DATE} to {END_DATE}...")

    raw = yf.download(
        all_tickers,
        start=START_DATE,
        end=END_DATE,
        auto_adjust=True,  # adjusts for splits/dividends -- important for momentum signals
        progress=True,
    )

    # yfinance returns a MultiIndex column DataFrame when multiple tickers are passed
    close = raw["Close"] if "Close" in raw.columns.get_level_values(0) else raw

    close = close.dropna(how="all")
    close.index.name = "Date"
    close.to_csv(OUT_PATH)

    print(f"Saved {close.shape[0]} rows x {close.shape[1]} tickers -> {OUT_PATH}")
    print(close.tail())


if __name__ == "__main__":
    main()
