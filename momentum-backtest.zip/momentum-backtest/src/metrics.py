"""
metrics.py
----------
Performance metric calculations used to evaluate both the strategy and the
benchmark. Kept separate from backtest.py so these functions are easy to
unit test and reuse.

All functions expect a pandas Series of periodic (daily) simple returns,
indexed by date, with no NaNs.
"""

import numpy as np
import pandas as pd

TRADING_DAYS_PER_YEAR = 252


def cumulative_return(daily_returns: pd.Series) -> float:
    """Total compounded return over the full period, e.g. 0.45 = +45%."""
    return (1 + daily_returns).prod() - 1


def cagr(daily_returns: pd.Series) -> float:
    """Compound Annual Growth Rate -- annualizes the total return by time elapsed."""
    n_days = len(daily_returns)
    total_return = (1 + daily_returns).prod()
    years = n_days / TRADING_DAYS_PER_YEAR
    if years <= 0 or total_return <= 0:
        return np.nan
    return total_return ** (1 / years) - 1


def annualized_volatility(daily_returns: pd.Series) -> float:
    """Standard deviation of daily returns, scaled to an annual figure."""
    return daily_returns.std() * np.sqrt(TRADING_DAYS_PER_YEAR)


def sharpe_ratio(daily_returns: pd.Series, risk_free_rate: float = 0.04) -> float:
    """
    Annualized Sharpe ratio: (annualized excess return) / (annualized volatility).

    risk_free_rate is an ANNUAL rate (default 4%, a rough approximation of
    recent T-bill yields). Converted to a daily rate before subtracting.
    """
    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS_PER_YEAR) - 1
    excess_returns = daily_returns - daily_rf
    if excess_returns.std() == 0:
        return np.nan
    return (excess_returns.mean() / excess_returns.std()) * np.sqrt(TRADING_DAYS_PER_YEAR)


def sortino_ratio(daily_returns: pd.Series, risk_free_rate: float = 0.04) -> float:
    """
    Like Sharpe, but only penalizes downside volatility (ignores upside swings).
    Useful because Sharpe punishes a strategy for being "too good" on the upside.
    """
    daily_rf = (1 + risk_free_rate) ** (1 / TRADING_DAYS_PER_YEAR) - 1
    excess_returns = daily_returns - daily_rf
    downside = excess_returns[excess_returns < 0]
    if len(downside) == 0 or downside.std() == 0:
        return np.nan
    return (excess_returns.mean() / downside.std()) * np.sqrt(TRADING_DAYS_PER_YEAR)


def max_drawdown(daily_returns: pd.Series) -> float:
    """
    Largest peak-to-trough decline in cumulative value, e.g. -0.32 = -32%.
    This is the number that tells you the worst pain you'd have sat through.
    """
    cumulative = (1 + daily_returns).cumprod()
    running_max = cumulative.cummax()
    drawdown = (cumulative - running_max) / running_max
    return drawdown.min()


def calmar_ratio(daily_returns: pd.Series) -> float:
    """CAGR divided by the absolute max drawdown -- return per unit of worst-case pain."""
    mdd = max_drawdown(daily_returns)
    if mdd == 0:
        return np.nan
    return cagr(daily_returns) / abs(mdd)


def win_rate(daily_returns: pd.Series) -> float:
    """Fraction of days with a positive return."""
    return (daily_returns > 0).mean()


def summary_table(daily_returns: pd.Series, risk_free_rate: float = 0.04) -> dict:
    """Bundle all metrics into a single dict for easy reporting/comparison."""
    return {
        "Cumulative Return": cumulative_return(daily_returns),
        "CAGR": cagr(daily_returns),
        "Annualized Volatility": annualized_volatility(daily_returns),
        "Sharpe Ratio": sharpe_ratio(daily_returns, risk_free_rate),
        "Sortino Ratio": sortino_ratio(daily_returns, risk_free_rate),
        "Max Drawdown": max_drawdown(daily_returns),
        "Calmar Ratio": calmar_ratio(daily_returns),
        "Win Rate": win_rate(daily_returns),
    }
