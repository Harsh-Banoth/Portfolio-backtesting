"""
generate_data.py
-----------------
Generates 5 years of daily OHLC price data for 8 large-cap tickers + SPY benchmark.

WHY THIS FILE EXISTS:
This sandbox environment cannot reach Yahoo Finance's API (network egress is
restricted). On your own machine, this is NOT needed -- just run:

    python src/fetch_data.py

...which pulls live data via yfinance. This generator exists only to produce
realistic placeholder data so the project runs end-to-end out of the box.

Each ticker's daily returns are simulated using Geometric Brownian Motion,
calibrated to that company's approximate real-world annualized return and
volatility (based on long-run historical averages as of early 2025). This
preserves realistic relative behavior (e.g., NVDA more volatile than KO)
so the momentum strategy produces sensible, explainable results.

Replace data/prices.csv with real data (via fetch_data.py) before treating
any conclusions in this project as investment advice.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

START_DATE = "2020-01-02"
END_DATE = "2024-12-31"

# (annualized return, annualized volatility) -- approximate historical regimes
TICKER_PARAMS = {
    "AAPL": (0.28, 0.30),
    "MSFT": (0.27, 0.28),
    "NVDA": (0.65, 0.55),
    "AMZN": (0.20, 0.34),
    "GOOGL": (0.22, 0.30),
    "JNJ":  (0.06, 0.16),
    "KO":   (0.09, 0.17),
    "XOM":  (0.15, 0.32),
    "SPY":  (0.14, 0.18),  # benchmark
}

TRADING_DAYS_PER_YEAR = 252


def generate_gbm_prices(start_price, mu, sigma, n_days, seed_offset=0):
    """Generate a price series using Geometric Brownian Motion."""
    rng = np.random.default_rng(42 + seed_offset)
    dt = 1 / TRADING_DAYS_PER_YEAR
    daily_drift = (mu - 0.5 * sigma ** 2) * dt
    daily_vol = sigma * np.sqrt(dt)

    shocks = rng.normal(loc=daily_drift, scale=daily_vol, size=n_days)
    log_prices = np.log(start_price) + np.cumsum(shocks)
    return np.exp(log_prices)


def add_market_correlation(returns_dict, market_key="SPY", beta_map=None):
    """Blend each stock's idiosyncratic returns with market returns for realism."""
    if beta_map is None:
        beta_map = {
            "AAPL": 1.1, "MSFT": 1.0, "NVDA": 1.7, "AMZN": 1.3,
            "GOOGL": 1.05, "JNJ": 0.55, "KO": 0.6, "XOM": 0.9,
        }
    market_ret = returns_dict[market_key]
    blended = {market_key: market_ret}
    for tic, ret in returns_dict.items():
        if tic == market_key:
            continue
        beta = beta_map.get(tic, 1.0)
        # 55% idiosyncratic, 45% market-driven (scaled by beta) -- a simple
        # one-factor approximation, not a real risk model.
        blended[tic] = 0.55 * ret + 0.45 * beta * market_ret
    return blended


def main():
    dates = pd.bdate_range(START_DATE, END_DATE)
    n_days = len(dates)

    start_prices = {
        "AAPL": 73.0, "MSFT": 157.0, "NVDA": 5.9, "AMZN": 94.0,
        "GOOGL": 68.0, "JNJ": 145.0, "KO": 55.0, "XOM": 70.0, "SPY": 321.0,
    }

    raw_log_returns = {}
    for i, (tic, (mu, sigma)) in enumerate(TICKER_PARAMS.items()):
        prices = generate_gbm_prices(start_prices[tic], mu, sigma, n_days, seed_offset=i)
        log_ret = np.diff(np.log(prices), prepend=np.log(start_prices[tic]))
        raw_log_returns[tic] = log_ret

    blended_returns = add_market_correlation(raw_log_returns)

    price_data = {}
    for tic, log_ret in blended_returns.items():
        log_price = np.log(start_prices[tic]) + np.cumsum(log_ret)
        price_data[tic] = np.exp(log_price)

    df = pd.DataFrame(price_data, index=dates)
    df.index.name = "Date"

    # Round to 2dp like real close prices
    df = df.round(2)

    out_path = "data/prices.csv"
    df.to_csv(out_path)
    print(f"Generated {len(df)} trading days x {len(df.columns)} tickers -> {out_path}")
    print(df.head(3))
    print("...")
    print(df.tail(3))


if __name__ == "__main__":
    main()
